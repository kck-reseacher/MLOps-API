import os
import traceback
import sys
import threading
import base64
import zlib
import struct
import queue as Queue
import time
import codec
from enum import Enum
from datetime import datetime

# logpresso modules
from .session import Session, LogpressoError
from .query import Query
from .codec import decode_map

class ByteBuffer:
	def __init__(self, data):
		self.__offset = 0
		self.__data = bytearray()
		self.__data.extend(data)

	def __inc(self, n):
		self.__offset += n

	def get(self, n = 1, increment = True):
		b = self.__data[self.__offset : self.__offset + n]
		if increment: self.__inc(n)
		return b

	def remaining(self):
		return len(self.__data) - self.__offset

	def get_char(self):
		return struct.unpack(">b", self.get(1))[0]

	def get_short(self):
		return struct.unpack(">h", self.get(2))[0]

	def get_int(self):
		return struct.unpack(">i", self.get(4))[0]

	def get_long(self):
		return struct.unpack(">q", self.get(8))[0]

	def get_float(self):
		return struct.unpack(">f", self.get(4))[0]

	def get_double(self):
		return struct.unpack(">d", self.get(8))[0]

	def get_str(self, n):
		return struct.unpack(str(n) + 's', self.get(n))[0]

class Cursor:
	def __init__(self, client, query_id: int, offset: int , limit: int, remove_on_close = True, fetch_unit = 10000):
		self.__client = client
		self.__query_id = query_id
		self.__offset = offset
		self.__limit = limit
		self.__remove_on_close = remove_on_close
		self.__p = offset
		self.__cached = None
		self.__current_cache_offset = None
		self.__next_cache_offset = offset
		self.__fetch_unit = fetch_unit
		self.__prefetch = None

	def __iter__(self):
		return self

	def __next__(self):
		if not self.__has_next():
			raise StopIteration

		item = self.__prefetch
		self.__prefetch = None
		return item

	def __has_next(self):
		if self.__prefetch != None:
			return True

		if (self.__p < self.__offset) or (self.__p > self.__offset + self.__limit):
			return False

		try:
			if self.__cached == None or self.__p >= self.__current_cache_offset + self.__fetch_unit:
				self.__cached = self.__client.get_result(self.__query_id, self.__next_cache_offset, self.__fetch_unit)
				self.__current_cache_offset = self.__next_cache_offset
				self.__next_cache_offset += self.__fetch_unit

			relative = self.__p - self.__current_cache_offset
			l = self.__cached.get('result')
			if relative >= len(l):
				return False

			self.__prefetch = l[relative]
			self.__p += 1
			return True

		except Exception as e:
			print('exception {}'.format(str(e)))
			return False

class LogpressoClient:
	"""
	Provides query management and fast result retrieval.
	"""
	def __init__(self):
		self.__session = None
		self.__queries = {}
		self.__stream_callbacks = {}

	def is_closed(self):
		return self.__session == None

	def connect(self, host, port, login_name: str, password: str):
		try:
			self.__session = Session(host, port, secure=False)
			self.__session.login(login_name, password)
			self.__session.add_callback(self.on_trap)
		except:
			self.close()
			raise

	def connect_ssl(self, host, port, login_name: str, password: str, verify_cert: bool = True):
		try:
			self.__session = Session(host, port, secure=True, verify_cert=verify_cert)
			self.__session.login(login_name, password)
			self.__session.add_callback(self.on_trap)
		except:
			self.close()
			raise

	def close(self):
		if self.__session != None:
			self.__session.remove_callback(self.on_trap)
			self.__session.close()
			self.__session = None

	def __enter__(self):
		return self

	def __exit__(self, type, value, traceback):
		self.close()

	def write(self, table_name, records: [], timeout=30):
		chunk = self.__encode_chunk(records)
		params = {}
		params['table'] = table_name
		params['bins'] = [ chunk ]
		self.rpc('org.araqne.logdb.msgbus.LogQueryPlugin.insertBatch', params, timeout)

	def query(self, query_string, result_set = None):
		query_id = self.create_query(query_string, result_set)
		self.start_query(query_id)
		q = self.__queries[query_id]
		if result_set:
			return result_set
		q.wait()
		if q.status == 'Cancelled':
			raise LogpressoError('query cancelled')

		total = q.loaded_count
		return Cursor(self, query_id, 0, total)

	def create_query(self, query_string, result_set=None):
		params = {}
		params['query'] = query_string
		params['source'] = 'python-client'
		resp = self.rpc('org.araqne.logdb.msgbus.LogQueryPlugin.createQuery', params, 0)
		id = resp.params['id']
		self.__session.register_trap('logdb-query-' + str(id))

		if result_set:
			self.__stream_callbacks[id] = result_set
			self.__session.register_trap('logdb-query-result-' + str(id))

		q = Query()
		q.id = id
		q.query_string = query_string
		self.__queries[id] = q
		return id

	def start_query(self, query_id):
		params = {}
		params['id'] = query_id
		params['streaming'] = query_id in self.__stream_callbacks
		self.rpc('org.araqne.logdb.msgbus.LogQueryPlugin.startQuery', params, 0)

	def stop_query(self, query_id):
		params = {}
		params['id'] = query_id
		self.rpc('org.araqne.logdb.msgbus.LogQueryPlugin.stopQuery', params, 0)

	def remove_query(self, query_id):
		self.__session.unregister_trap('logdb-query-' + str(query_id))

		params = {}
		params['id'] = query_id
		self.rpc('org.araqne.logdb.msgbus.LogQueryPlugin.removeQuery', params, 0)

		self.__queries.pop(query_id, None)

	def get_queries(self):
		resp = self.rpc('org.araqne.logdb.msgbus.LogQueryPlugin.queries', {}, 0)
		queries = []
		for o in resp.params['queries']:
			q = self.__parse_query(o)
			queries.append(q)

		return queries

	def __parse_query(self, o):
		q = Query()
		q.id = o.get('id')
		q.query_string = o.get('query_string')
		q.source = o.get('source')
		q.login_name = o.get('login_name')
		q.remote_ip = o.get('remote_ip')
		q.background = o.get('background')
		q.elapsed = o.get('elapsed')

		stamp = o.get('stamp')
		q.update_count(o.get('rows'), stamp)

		end = o.get('is_end')
		eof = end
		if 'is_eof' in o:
			eof = o.get('is_eof')
		
		cancelled = False
		if 'is_cancelled' in o:
			cancelled = o.get('is_cancelled')

		if eof:
			if cancelled:
				q.update_status('Cancelled', stamp)
			else:
				q.update_status('Ended', stamp)
		elif end:
			q.update_status('Stopped', stamp)
		else:
			q.update_status('Running', stamp)

		return q

	def get_result(self, query_id, offset, limit):
		params = {}
		params['id'] = query_id
		params['offset'] = offset
		params['limit'] = limit
		params['binary_encode'] = True

		resp = self.rpc('org.araqne.logdb.msgbus.LogQueryPlugin.getResult', params, 0)
		if len(resp.params) == 0:
			raise LogpressoError('query-not-found')

		binary = resp.params['binary']
		size = resp.params['uncompressed_size']
		return self.__decode_chunk(binary, size)

	def rpc(self, method, params, timeout):
		return self.__session.rpc(method, params, timeout)

	def on_trap(self, msg):
		method = msg.method
		stamp = int(msg.params.get('stamp')) if 'stamp' in msg.params else 0

		if method.startswith('logdb-query-result-'):
			self.__handle_streaming_result(msg, stamp)
		elif method.startswith('logdb-query-'):
			query_id = msg.params.get('id')
			q = self.__queries[query_id]
			self.__update_query_status(msg, stamp, q)
		else:
			print('unsupported trap: ' + str(msg))
		
	def __update_query_status(self, msg, stamp, query):
		msg_type = msg.params.get('type')

		if msg_type == 'eof':
			count = msg.params.get('total_count')
			query.update_count(count, stamp)

			cancel_reason = msg.params.get('cancel_reason')
			if cancel_reason != None and cancel_reason != 'PARTIAL_FETCH':
				query.cancel_reason = cancel_reason
				query.error_code = msg.params.get('error_code')
				query.error_detail = msg.params.get('error_detail')
				query.update_status('Cancelled', stamp)
			else:
				query.update_status('Ended', stamp)
		elif msg_type == 'status_change':
			count = msg.params.get('count')
			status = msg.params.get('status')
			query.update_count(count, stamp)
			query.update_status(status, stamp)

		query.stamp = stamp

	def __handle_streaming_result(self, msg, stamp):
		chunks = msg.params.get('bins')
		last = msg.params.get('last')
		queryId = int(msg.method[len('logdb-query-result-'):])

		try:
			query = self.__queries[queryId]
			rs = self.__stream_callbacks[queryId]
			rows = self.__stream_decode(chunks) if chunks else msg.params.get('rows')
			if query and rs:
				if 'stamp' in msg.params:
					self.__update_query_status(msg, stamp, query)
				rs.on_rows(query, rows, last)
		except:
			traceback.print_exc(file=sys.stdout)
			raise

	def __stream_decode(self, chunks):
		rows = []
		for chunk in chunks:
			rows.extend(self.__decode_chunk(chunk['bin'], chunk['size'], True))

		return rows

	def __encode_chunk(self, records: []):
		vecs = {}
		i = 0
		count = len(records)
		for record in records:
			for key in record:
				vec = None
				if key in vecs:
					vec = vecs[key]
				else:
					vec = [None] * count
					vecs[key] = vec

				vec[i] = record[key]

			i = i + 1

		time_vec = None
		if '_time' in vecs:
			time_vec = [datetime.now() if v is None else v for v in vecs['_time']]
		else:
			time_vec = [datetime.now()] * count

		vecs['_time'] = time_vec

		blob = codec.encode(vecs)
		return codec.encode_chunk(blob)

	def __decode_chunk(self, binary, size, columnar=False):
		direction = 1 if columnar else 0
		return codec.decode_chunk(binary, size, direction)

class StreamingResultSet:
	def __init__(self, client):
		self.__client = client
		self.__done = False
		self.__buffer = Queue.Queue(10)
		self.__event = threading.Event()
		self.__thread = threading.Thread(target=self.__get)
		self.__thread.start()

	def on_rows(self, query, rows, last):
		self.__buffer.put(rows)
		if not self.__event.is_set():
			self.__event.set()
		if last:
			self.__done = True

	def get_bulks(self):
		for rows in self.__get():
			yield rows

	def __get(self):
		while not self.__done:
			while not self.__buffer.empty():
				yield self.__buffer.get()
			self.__event.wait()
		while not self.__buffer.empty():
			yield self.__buffer.get()
