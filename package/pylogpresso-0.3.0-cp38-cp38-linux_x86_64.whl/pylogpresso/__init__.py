"""
pylogpresso
=============

Logpresso provides websocket protocol based client SDK to build big data applications.
"""
from .client import LogpressoClient

def connect(host: str, port: int, user: str, password: str):
	client = LogpressoClient()
	client.connect(host, port, user, password)
	return client

def connect_ssl(host: str, port: int, user: str, password: str, verify_ssl: bool = True):
	client = LogpressoClient()
	client.connect_ssl(host, port, user, password, verify_ssl)
	return client
