from enum import Enum
from datetime import datetime
import sys
import traceback

class EncodingType(Enum):
    NULL = 0
    BOOLEAN = 1
    # INT16 = 2
    # INT32 = 3
    # INT64 = 4
    STRING = 5
    DATE = 6
    IP4 = 7
    IP6 = 8
    MAP = 9
    ARRAY = 10
    BLOB = 11
    SHORT = 12
    INT = 13
    LONG = 14
    FLOAT = 15
    DOUBLE = 16

def decode(data):
    try:
        typeByte = data.get(increment = False)[0]
        func = decode_function[EncodingType(typeByte)]
        if func != None:
            return func(data)
        raise ValueError("Unsupported type: " + str(typeByte))
    except:
        traceback.print_exc(file=sys.stdout)

def decode_null(data):
    data.get()
    return None

def decode_boolean(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.BOOLEAN:
        raise ValueError('EncodingType must be BOOLEAN(1), but was ' + str(t))
    return data.get_char() == 1

def decode_string(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.STRING:
        raise ValueError('EncodingType must be STRING(5), but was ' + str(t))
    l = decode_raw_number(data)
    return data.get_str(l).decode("utf-8")

def decode_date(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.DATE:
        raise ValueError('EncodingType must be DATE(6), but was ' + str(t))
    return datetime.fromtimestamp(data.get_long() / 1000)

def decode_ip4(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.IP4:
        raise ValueError('EncodingType must be IP4(7), but was ' + str(t))
    return '.'.join([str(i) for i in data.get(4)])

def decode_ip6(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.IP6:
        raise ValueError('EncodingType must be IP6(8), but was ' + str(t))
    x = data.get_str(16).encode('hex')
    return ':'.join(x[i:i+4] for i in range(0, len(x), 4))

def decode_map(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.MAP:
        raise ValueError('EncodingType must be MAP(9), but was ' + str(t))
    l = decode_raw_number(data)
    m = {}

    while l > 0:
        before = data.remaining()
        key = decode_string(data)
        value = decode(data)
        after = data.remaining()
        m[key] = value
        l -= (before - after)

    return m

def decode_array(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.ARRAY:
        raise ValueError('EncodingType must be ARRAY(10), but was ' + str(t))
    l = decode_raw_number(data)
    v = []

    while l > 0:
        before = data.remaining()
        v.append(decode(data))
        after = data.remaining()
        l -= (before - after)

    return v

def decode_blob(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.BLOB:
        raise ValueError('EncodingType must be BLOB(11), but was ' + str(t))
    l = decode_raw_number(data)
    return data.get_str(l).encode('hex')

def decode_short(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.SHORT:
        raise ValueError('EncodingType must be SHORT(12), but was ' + str(t))
    l = decode_raw_number(data)
    return ((l >> 1) & 0x7fff) ^ - (l & 1)

def decode_int(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.INT:
        raise ValueError('EncodingType must be INT(13), but was ' + str(t))
    l = decode_raw_number(data)
    return ((l >> 1) & 0x7fffffff) ^ - (l & 1)

def decode_long(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.LONG:
        raise ValueError('EncodingType must be LONG(14), but was ' + str(t))
    l = decode_raw_number(data)
    return ((l >> 1) & 0x7fffffffffffffff) ^ - (l & 1)

def decode_float(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.FLOAT:
        raise ValueError('EncodingType must be FLOAT(15), but was ' + str(t))
    return data.get_float()

def decode_double(data):
    t = data.get_char()
    if EncodingType(t) != EncodingType.DOUBLE:
        raise ValueError('EncodingType must be DOUBLE(16), but was ' + str(t))
    return data.get_double()

def decode_raw_number(data):
    val = 0
    while True:
        val <<= 7
        b = data.get_char()
        val |= b & 0x7f
        if (b & 0x80) == 0x80:
            continue
        break
    return val

decode_function = {
    EncodingType.NULL : decode_null,
    EncodingType.BOOLEAN: decode_boolean,
    EncodingType.STRING : decode_string,
    EncodingType.DATE : decode_date,
    EncodingType.IP4 : decode_ip4,
    EncodingType.IP6 : decode_ip6,
    EncodingType.MAP : decode_map,
    EncodingType.ARRAY : decode_array,
    EncodingType.BLOB : decode_blob,
    EncodingType.SHORT : decode_short,
    EncodingType.INT : decode_int,
    EncodingType.LONG : decode_long,
    EncodingType.FLOAT : decode_float,
    EncodingType.DOUBLE : decode_double
} 